package com.fuzzyrock.spring.mvc.validationdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidationdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
